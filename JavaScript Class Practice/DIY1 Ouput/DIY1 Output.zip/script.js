let myName = 'Nichita Mladin';
let myAddress = 'Bucharest, Romania';

console.log(myName, myAddress);
alert(myName);
alert(myAddress);