function array(num1, num2, num3){
    let ar = [num1, num2, num3];
    return ar.reverse();
}

console.log(array(4, 6, 10));