let computer = {
    price: 10000,
    color: "black",
    memory: "16GB"
};