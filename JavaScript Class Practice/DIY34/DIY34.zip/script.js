function displayMinimumNumber(n1, n2, n3){
    let minimumNumber = Math.min(n1, n2, n3);
    alert("Minimum number is: " + minimumNumber);
}

displayMinimumNumber(3, 5, 9);