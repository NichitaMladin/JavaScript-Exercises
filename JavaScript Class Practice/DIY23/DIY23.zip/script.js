let numberSet = new Set([1, 2, 3]);
console.log(numberSet);